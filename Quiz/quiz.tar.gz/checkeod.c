int check(int x){
  if(x%2 == 0){
    return 1;
  }else{
    return 2;
  }
}
